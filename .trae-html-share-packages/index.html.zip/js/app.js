/**
 * 应用入口模块
 * 包含初始化、事件绑定、主题切换等
 */
 
import { CONFIG } from './config.js?v=1.3.2';
import {
  state,
  loadSessions,
  createSession,
  saveSessions,
  deleteSession,
  removeMessageData,
  saveChatHistory,
  chatData,
  currentSession,
  clearAllLocalSessions,
  loadAllFromServer,
  clearCurrentSessionMessages,
  refreshFromServer,
  ensureEmptySession
} from './state.js?v=1.3.2';
import {
  getDOMElements,
  domRefs as renderRefs,
  renderCurrentSession,
  renderEmptyState,
  hideMsgActionMenu,
  currentActionMenu,
  hideConfirm,
  openSidebar,
  closeSidebar,
  confirmDeleteSession,
  renderSidebarList
} from './render.js?v=1.3.2';
import {
  sendMessage,
  toggleSendButton,
  stopGeneration
} from './chat.js?v=1.3.2';
import {
  initVoices,
  initStreamTTS,
  updateHeaderPlayBtn,
  stopAllSpeak,
  pauseStreamTTS,
  resumeStreamTTS,
  getStreamTTSState
} from './tts.js?v=1.3.2';
import {
  register,
  login,
  logout,
  fetchMe,
  isLoggedIn,
  currentUser
} from './auth.js?v=1.3.2';
 
// ================================================================
// 事件绑定
// ================================================================
 
export function setupChat() {
  var dom = getDOMElements();
 
  // 输入框
  dom.chatInput.addEventListener("input", updateInputHeight);
  dom.chatInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      sendMessage();
    }
  });
 
  // 发送/停止按钮
  dom.chatSendBtn.addEventListener("click", sendMessage);
 
  // 新话题
  dom.chatNewBtn.addEventListener("click", startNewSession);
  dom.chatSidebarNewBtn.addEventListener("click", startNewSession);
  if (dom.chatSidebarRefreshBtn) {
    dom.chatSidebarRefreshBtn.addEventListener("click", function() {
      refreshFromServer().then(function() {
        renderSidebarList();
        renderCurrentSession();
      });
    });
  }
 
  // 主题切换
  if (dom.chatThemeBtn) dom.chatThemeBtn.addEventListener("click", toggleTheme);

  // 语音播报播放/暂停
  if (dom.chatAutoPlayBtn) dom.chatAutoPlayBtn.addEventListener("click", togglePlayPause);
 
  // 侧栏
  var chatMenuBtn = document.getElementById("chatMenuBtn");
  if (chatMenuBtn) {
    chatMenuBtn.addEventListener("click", openSidebar);
    chatMenuBtn.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openSidebar();
      }
    });
  }
  dom.chatSidebarClose.addEventListener("click", closeSidebar);
  dom.chatSidebarOverlay.addEventListener("click", closeSidebar);
 
  // 确认弹窗
  dom.chatConfirmCancel.addEventListener("click", hideConfirm);
  dom.chatConfirmOk.addEventListener("click", onConfirmOk);
  dom.chatConfirmOverlay.addEventListener("click", function (e) {
    if (e.target === dom.chatConfirmOverlay) hideConfirm();
  });
 
  // Esc 关闭弹窗
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      if (currentActionMenu) {
        hideMsgActionMenu();
      } else if (dom.chatConfirmOverlay.classList.contains("show")) {
        hideConfirm();
      } else if (document.getElementById("chatSidebar").classList.contains("open")) {
        closeSidebar();
      }
    }
    trapFocus(e);
  });
 
  // 点击外部关闭菜单
  document.addEventListener("click", function (e) {
    if (currentActionMenu && !currentActionMenu.contains(e.target)) {
      hideMsgActionMenu();
    }
  }, true);
  document.addEventListener("touchstart", function (e) {
    if (currentActionMenu && !currentActionMenu.contains(e.target)) {
      hideMsgActionMenu();
    }
  }, { passive: true });
 
  // 滚动/改变尺寸关闭菜单
  window.addEventListener("scroll", hideMsgActionMenu, true);
  window.addEventListener("resize", hideMsgActionMenu);
 
  // 页面卸载
  window.addEventListener("beforeunload", function () {
    if (state.abortController) state.abortController.abort();
  });
 
  // 重新回答事件
  document.addEventListener('chat:regenerate', function (e) {
    sendMessage();
  });

  // 切换会话事件
  document.addEventListener('chat:switchSession', function (e) {
    if (e.detail && e.detail.id) {
      state.currentSessionId = e.detail.id;
      saveSessions();
    }
  });

  // 发送消息事件（追问按钮等触发）
  document.addEventListener('chat:send', function () {
    sendMessage();
  });
 
  // 认证相关
  setupAuth();
 
  // 初始化会话
  loadSessions();
  initVoices();
  initStreamTTS();
  updateHeaderPlayBtn();

  // 确保始终有一个空话题
  ensureEmptySession();
  if (!state.currentSessionId) {
    state.currentSessionId = state.sessions[0].id;
  }
  renderCurrentSession();
  dom.chatInput.focus();
 
  // 初始化主题
  initTheme();

  // 多标签页数据同步（第五条）
  setupMultiTabSync();
}
 
// ================================================================
// 多标签页数据同步（storage事件 + visibilitychange事件）
// ================================================================
 
var _syncThrottleTimer = null;
var _lastServerRefresh = 0;
var SERVER_REFRESH_INTERVAL = 300000; // 5分钟
 
function setupMultiTabSync() {
  // 1) 监听 storage 事件：其他标签页修改 localStorage 时触发
  //    只同步本地状态变更（如删除消息），不从服务端拉取
  window.addEventListener('storage', function (e) {
    if (!e.key) return;
    console.log('[灵知] storage事件 - key:', e.key);
 
    
    if (e.key === CONFIG.STORAGE_KEY || e.key === CONFIG.STORAGE_KEY + '_deleted') {
     
      if (_syncThrottleTimer) return;
      _syncThrottleTimer = setTimeout(function () {
        _syncThrottleTimer = null;
      
        console.log('[灵知] 检测到其他标签页数据变更，同步本地状态');
        loadSessions();
        renderSidebarList();
        renderCurrentSession();
   
      }, 800);
    }
  });
 
  // 2) 监听 visibilitychange 事件：页面从后台切换回前台时静默刷新服务端数据
  //    - 只更新侧栏列表，不重新渲染当前会话，避免打断用户阅读
  //    - 节流：至少间隔 SERVER_REFRESH_INTERVAL 才刷新一次
  document.addEventListener('visibilitychange', function () {
  
    if (document.hidden) return;
    if (!isLoggedIn()) return;

    var now = Date.now();
    if (now - _lastServerRefresh < SERVER_REFRESH_INTERVAL) {
      return;
    }
    _lastServerRefresh = now;

    setTimeout(function () {
      // 静默刷新：只更新侧栏列表，不重渲染当前会话（避免打断用户阅读）
      refreshFromServer().then(function () {
        renderSidebarList();
      });
    }, 500);
  });
}
 
// ================================================================
// 输入框高度自适应
// ================================================================
 
var _inputResizeRaf = null;
 
function updateInputHeight() {
  if (_inputResizeRaf) return;
  _inputResizeRaf = requestAnimationFrame(function () {
    _inputResizeRaf = null;
    var h = renderRefs.chatInput.scrollHeight;
    if (h > CONFIG.MAX_TEXTAREA_HEIGHT) h = CONFIG.MAX_TEXTAREA_HEIGHT;
    renderRefs.chatInput.style.height = "auto";
    renderRefs.chatInput.style.height = h + "px";
  });
}
 
// ================================================================
// 主题切换
// ================================================================
 
function initTheme() {
  var savedTheme = null;
  try { savedTheme = localStorage.getItem(CONFIG.THEME_STORAGE_KEY); } catch (e) {}
  applyTheme(savedTheme);
}
 
function applyTheme(theme) {
  if (theme === "dark") {
    document.body.classList.add("is-dark");
  } else if (theme === "light") {
    document.body.classList.remove("is-dark");
  } else {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      document.body.classList.add("is-dark");
    } else {
      document.body.classList.remove("is-dark");
    }
  }
  var chatThemeBtn = document.getElementById("chatThemeBtn");
  if (chatThemeBtn) {
    chatThemeBtn.setAttribute(
      "title",
      document.body.classList.contains("is-dark") ? "切换到浅色模式" : "切换到深色模式"
    );
  }
}
 
function toggleTheme() {
  var isDark = document.body.classList.contains("is-dark");
  var next = isDark ? "light" : "dark";
  try { localStorage.setItem(CONFIG.THEME_STORAGE_KEY, next); } catch (e) {}
  applyTheme(next);
}
 
// ================================================================
// 语音播报播放/暂停
// ================================================================

function togglePlayPause() {
  var streamState = getStreamTTSState();
  if (!streamState) return;
  if (streamState.isPlaying) {
    pauseStreamTTS();
  } else if (streamState.isPaused) {
    resumeStreamTTS();
  }
}

// ================================================================
// 确认弹窗处理
// ================================================================
 
function onConfirmOk() {
  if (!state.pendingOperation) {
    hideConfirm();
    return;
  }
 
  if (state.pendingOperation.type === 'session') {
    var sid = state.pendingOperation.id;
    state.pendingOperation = null;
    hideConfirm();
    deleteSession(sid);
    renderSidebarList();
    renderCurrentSession();
    return;
  }
 
  if (state.pendingOperation.type === 'msg') {
    var id = parseInt(state.pendingOperation.msgDiv.dataset.msgId, 10);
    removeMessageData(id);
    state.pendingOperation.msgDiv.remove();
    state.pendingOperation = null;
    saveChatHistory();
    if (chatData().length === 0) renderEmptyState();
    hideConfirm();
    return;
  }
 
  if (state.pendingOperation.type === 'clearAll') {
    if (state.abortController) { state.abortController.abort(); state.abortController = null; }
    toggleSendButton(false);
    clearCurrentSessionMessages();
    renderEmptyState();
    hideConfirm();
    return;
  }
 
  state.pendingOperation = null;
  hideConfirm();
}
 
function trapFocus(e) {
  var chatConfirmOverlay = document.getElementById("chatConfirmOverlay");
  if (!chatConfirmOverlay.classList.contains("show")) return;
  if (e.key !== "Tab") return;
  var focusable = chatConfirmOverlay.querySelectorAll("button");
  if (!focusable.length) return;
  var first = focusable[0];
  var last = focusable[focusable.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
}
 
// ================================================================
// 新话题
// ================================================================
 
function startNewSession() {
  if (state.abortController) { state.abortController.abort(); state.abortController = null; }
  toggleSendButton(false);
 
  var cur = currentSession();
  if (cur && cur.messages.length === 0) {
    closeSidebar();
    renderEmptyState();
    renderRefs.chatInput.focus();
    return;
  }
 
  createSession();
  closeSidebar();
  renderEmptyState();
  renderRefs.chatInput.focus();
}
 
// ================================================================
// 认证（登录/注册）
// ================================================================
 
var _authMode = 'login';
 
var _userMenu = null;

function setupAuth() {
  var userBtn = document.getElementById('authUserBtn');
  var overlay = document.getElementById('authOverlay');
  var closeBtn = document.getElementById('authCloseBtn');
  var submitBtn = document.getElementById('authSubmitBtn');
  var switchBtn = document.getElementById('authSwitchBtn');
  var nicknameField = document.getElementById('authNicknameField');
  var title = document.getElementById('authTitle');
  var switchText = document.getElementById('authSwitchText');

  _userMenu = document.getElementById('userMenu');

  if (userBtn) {
    userBtn.addEventListener('click', function () {
      if (isLoggedIn()) {
        toggleUserMenu();
      } else {
        openAuthModal('login');
      }
    });
  }

  // 生图按钮
  var imageGenBtn = document.getElementById('userMenuImageGen');
  if (imageGenBtn) {
    imageGenBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideUserMenu();
      window.open('https://shitou-git.github.io/Image/st', '_blank');
    });
  }

  // 关于按钮
  var aboutBtn = document.getElementById('userMenuAbout');
  if (aboutBtn) {
    aboutBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideUserMenu();
      openAboutModal();
    });
  }

  // 关于弹窗关闭
  var aboutOverlay = document.getElementById('aboutOverlay');
  var aboutCloseBtn = document.getElementById('aboutCloseBtn');
  var aboutOkBtn = document.getElementById('aboutOkBtn');

  function openAboutModal() {
    if (!aboutOverlay) return;

    var versionEl = document.getElementById('aboutVersion');
    var descEl = document.getElementById('aboutDesc');
    var modelEl = document.getElementById('aboutModel');
    var titleEl = document.getElementById('aboutTitle');

    if (titleEl && CONFIG.APP_NAME) titleEl.textContent = CONFIG.APP_NAME;
    if (versionEl && CONFIG.APP_VERSION) versionEl.textContent = CONFIG.APP_VERSION;
    if (descEl && CONFIG.APP_DESCRIPTION) descEl.textContent = CONFIG.APP_DESCRIPTION;
    if (modelEl && CONFIG.MODEL_DISPLAY) modelEl.textContent = CONFIG.MODEL_DISPLAY;

    aboutOverlay.classList.add('show');
  }

  function closeAboutModal() {
    if (aboutOverlay) aboutOverlay.classList.remove('show');
  }

  if (aboutCloseBtn) {
    aboutCloseBtn.addEventListener('click', closeAboutModal);
  }
  if (aboutOkBtn) {
    aboutOkBtn.addEventListener('click', closeAboutModal);
  }
  if (aboutOverlay) {
    aboutOverlay.addEventListener('click', function (e) {
      if (e.target === aboutOverlay) closeAboutModal();
    });
  }

  // 设置按钮
  var settingsBtn = document.getElementById('userMenuSettings');
  var settingsOverlay = document.getElementById('settingsOverlay');
  var settingsCloseBtn = document.getElementById('settingsCloseBtn');
  var settingsOkBtn = document.getElementById('settingsOkBtn');

  function openSettingsModal() {
    if (!settingsOverlay) return;

    // 填充账号信息
    var loginStatusEl = document.getElementById('settingsLoginStatus');
    var nicknameEl = document.getElementById('settingsNickname');
    var emailEl = document.getElementById('settingsEmail');
    var user = currentUser();
    if (user) {
      if (loginStatusEl) loginStatusEl.textContent = '已登录';
      if (nicknameEl) nicknameEl.textContent = user.nickname || user.name || '-';
      if (emailEl) emailEl.textContent = user.email || '-';
    } else {
      if (loginStatusEl) loginStatusEl.textContent = '未登录';
      if (nicknameEl) nicknameEl.textContent = '-';
      if (emailEl) emailEl.textContent = '-';
    }

    // 渲染模型列表
    renderModelList();

    // 渲染语音列表
    renderVoiceList();

    settingsOverlay.classList.add('show');
  }

  function closeSettingsModal() {
    if (settingsOverlay) settingsOverlay.classList.remove('show');
  }

  function renderModelList() {
    var selectEl = document.getElementById('settingsModelSelect');
    if (!selectEl || !CONFIG.MODEL_OPTIONS) return;
    var savedModel = localStorage.getItem(CONFIG.MODEL_STORAGE_KEY) || CONFIG.MODEL;
    selectEl.innerHTML = '';
    CONFIG.MODEL_OPTIONS.forEach(function (opt) {
      var option = document.createElement('option');
      option.value = opt.id;
      option.textContent = opt.name + '（' + opt.desc + '）';
      if (opt.id === savedModel) option.selected = true;
      selectEl.appendChild(option);
    });
    selectEl.onchange = function () {
      localStorage.setItem(CONFIG.MODEL_STORAGE_KEY, selectEl.value);
    };
  }

  function renderVoiceList() {
    var selectEl = document.getElementById('settingsVoiceSelect');
    if (!selectEl || !CONFIG.TTS_VOICES) return;
    var savedVoice = localStorage.getItem('tts_voice') || CONFIG.TTS_DEFAULT_VOICE;
    selectEl.innerHTML = '';
    CONFIG.TTS_VOICES.forEach(function (voice) {
      var opt = document.createElement('option');
      opt.value = voice.id;
      opt.textContent = voice.name + '（' + voice.emotion + '）';
      if (voice.id === savedVoice) opt.selected = true;
      selectEl.appendChild(opt);
    });
    selectEl.onchange = function () {
      localStorage.setItem('tts_voice', selectEl.value);
    };
  }

  if (settingsBtn) {
    settingsBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideUserMenu();
      openSettingsModal();
    });
  }
  if (settingsCloseBtn) {
    settingsCloseBtn.addEventListener('click', closeSettingsModal);
  }
  if (settingsOkBtn) {
    settingsOkBtn.addEventListener('click', closeSettingsModal);
  }
  if (settingsOverlay) {
    settingsOverlay.addEventListener('click', function (e) {
      if (e.target === settingsOverlay) closeSettingsModal();
    });
  }

  // 退出按钮
  var logoutBtn = document.getElementById('userMenuLogout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideUserMenu();
      if (confirm('确定要退出登录吗？退出后本地聊天记录将被清除。')) {
        logout();
      }
    });
  }

  // 点击其他地方关闭菜单
  document.addEventListener('click', function (e) {
    if (_userMenu && !_userMenu.contains(e.target)) {
      var userBtn = document.getElementById('authUserBtn');
      if (!userBtn || !userBtn.contains(e.target)) {
        hideUserMenu();
      }
    }
  });
 
  if (closeBtn) {
    closeBtn.addEventListener('click', closeAuthModal);
  }
  if (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeAuthModal();
    });
  }
 
  if (switchBtn) {
    switchBtn.addEventListener('click', function () {
      if (_authMode === 'login') {
        openAuthModal('register');
      } else {
        openAuthModal('login');
      }
    });
  }
 
  if (submitBtn) {
    submitBtn.addEventListener('click', handleAuthSubmit);
  }
 
  ['authEmail', 'authPassword', 'authNickname'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) {
      el.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleAuthSubmit();
        }
      });
    }
  });
 
  var _lastLoginState = isLoggedIn();
  console.log('[灵知] setupAuth - 初始登录状态:', _lastLoginState);
  document.addEventListener('auth:changed', function () {
    var nowLoggedIn = isLoggedIn();
    console.log('[灵知] auth:changed - 之前:', _lastLoginState, ', 现在:', nowLoggedIn);
    updateAuthUI();
    if (nowLoggedIn) {
      if (!_lastLoginState) {
        console.log('[灵知] auth:changed - 从登出变为登录，调用 handleLogin');
        handleLogin();
      } else {
        console.log('[灵知] auth:changed - 已是登录状态，跳过 handleLogin');
      }
    } else {
      if (_lastLoginState) {
        console.log('[灵知] auth:changed - 从登录变为登出，调用 handleLogout');
        handleLogout();
      }
    }
    _lastLoginState = nowLoggedIn;
  });
 
  updateAuthUI();
 
  if (isLoggedIn()) {
    console.log('[灵知] setupAuth - 页面加载时已登录，调用 fetchMe 和 handleLogin');
    fetchMe();
    handleLogin();
  }
}
 
function openAuthModal(mode) {
  _authMode = mode || 'login';
  var overlay = document.getElementById('authOverlay');
  var nicknameField = document.getElementById('authNicknameField');
  var title = document.getElementById('authTitle');
  var switchText = document.getElementById('authSwitchText');
  var switchBtn = document.getElementById('authSwitchBtn');
  var submitBtn = document.getElementById('authSubmitBtn');
  var errorEl = document.getElementById('authError');
 
  if (!overlay) return;
 
  if (mode === 'register') {
    title.textContent = '注册账号';
    nicknameField.style.display = 'block';
    switchText.textContent = '已有账号？';
    switchBtn.textContent = '去登录';
    submitBtn.textContent = '注册';
  } else {
    title.textContent = '登录';
    nicknameField.style.display = 'none';
    switchText.textContent = '还没有账号？';
    switchBtn.textContent = '去注册';
    submitBtn.textContent = '登录';
  }
 
  errorEl.textContent = '';
  document.getElementById('authEmail').value = '';
  document.getElementById('authPassword').value = '';
  var nickInput = document.getElementById('authNickname');
  if (nickInput) nickInput.value = '';
 
  overlay.classList.add('show');
  setTimeout(function () {
    document.getElementById('authEmail').focus();
  }, 100);
}
 
function closeAuthModal() {
  var overlay = document.getElementById('authOverlay');
  if (overlay) overlay.classList.remove('show');
}
 
function handleAuthSubmit() {
  var emailEl = document.getElementById('authEmail');
  var passwordEl = document.getElementById('authPassword');
  var nicknameEl = document.getElementById('authNickname');
  var errorEl = document.getElementById('authError');
  var submitBtn = document.getElementById('authSubmitBtn');
 
  var email = emailEl.value.trim();
  var password = passwordEl.value;
  var nickname = nicknameEl ? nicknameEl.value.trim() : '';
 
  if (!email) {
    errorEl.textContent = '请输入邮箱';
    return;
  }
  if (!password) {
    errorEl.textContent = '请输入密码';
    return;
  }
  if (_authMode === 'register' && password.length < 6) {
    errorEl.textContent = '密码至少 6 位';
    return;
  }
 
  submitBtn.disabled = true;
  errorEl.textContent = '';
 
  var action = _authMode === 'register'
    ? register(email, password, nickname)
    : login(email, password);
 
  action.then(function () {
    submitBtn.disabled = false;
    closeAuthModal();
  }).catch(function (err) {
    submitBtn.disabled = false;
    errorEl.textContent = err.message || '操作失败';
  });
}
 
function updateAuthUI() {
  var userNameEl = document.getElementById('authUserName');
  if (!userNameEl) return;

  var user = currentUser();
  if (user) {
    userNameEl.textContent = user.nickname || user.email;
  } else {
    userNameEl.textContent = '未登录';
  }
}

function toggleUserMenu() {
  if (!_userMenu) return;
  _userMenu.classList.toggle('show');
}

function hideUserMenu() {
  if (!_userMenu) return;
  _userMenu.classList.remove('show');
}
 
/** 退出登录后清理：清除本地聊天记录、重置界面 */
function handleLogout() {
  hideUserMenu();

  // 停止生成中内容
  if (state.abortController) {
    state.abortController.abort();
    state.abortController = null;
  }
  toggleSendButton(false);
  stopAllSpeak();
  updateHeaderPlayBtn();
 
  // 清除本地所有会话
  clearAllLocalSessions();
 
  // 创建一个新的空会话
  createSession();
 
  // 直接清空聊天消息 DOM，确保消息被清除（强制刷新）
  var chatMessagesEl = document.getElementById('chatMessages');
  if (chatMessagesEl) {
    chatMessagesEl.innerHTML = '';
    chatMessagesEl.innerHTML = '<div class="chat-empty-tip"><span class="big">👋</span>你好！我是灵知</div>';
  }
 
  // 重新渲染侧边栏
  renderSidebarList();
 
  // 清空输入框
  if (renderRefs.chatInput) {
    renderRefs.chatInput.value = '';
    renderRefs.chatInput.style.height = 'auto';
    renderRefs.chatInput.focus();
  }
 
  // 最后更新用户 UI（这会更新显示"未登录"）
  updateAuthUI();
}
 
/** 登录后处理：从服务端静默加载历史聊天记录
 *  - 第一次打开页面时，loadSessions 已加载本地数据并选中第一个会话
 *  - 登录后从服务端拉取数据，但只更新侧栏，不重渲染当前会话
 *  - 用户正在阅读的话题不会被打断 */
function handleLogin() {
  console.log('[灵知] handleLogin - 静默加载服务端数据...');
  var currentId = state.currentSessionId;
  loadAllFromServer().then(function () {
    console.log('[灵知] handleLogin - 服务端数据加载完成，会话数:', state.sessions.length);
    // 强制恢复当前会话选择（只要该会话还在列表中），避免跳转到空话题
    if (currentId && state.sessions.some(function(s) { return s.id === currentId; })) {
      state.currentSessionId = currentId;
      saveSessions();
    }
    // 静默加载：只更新侧栏列表，不重渲染当前会话
    renderSidebarList();
  }).catch(function(err) {
    console.error('[灵知] handleLogin - 加载服务端数据失败:', err);
    renderSidebarList();
  });
}
 
// ================================================================
// 暴露到全局（供 HTML 内联事件和调试用）
// ================================================================

window.startNewSession = startNewSession;
window.openSidebar = openSidebar;
window.closeSidebar = closeSidebar;
window.renderSidebarList = renderSidebarList;
window.confirmDeleteSession = confirmDeleteSession;
window.sendMessage = sendMessage;
window.togglePlayPause = togglePlayPause;

// 重新导出 state 到全局（调试用）
Object.defineProperty(window, 'state', {
  get: function() { return state; }
});
Object.defineProperty(window, 'sessions', {
  get: function() { return state.sessions; }
});
Object.defineProperty(window, 'currentSessionId', {
  get: function() { return state.currentSessionId; },
  set: function(val) { state.currentSessionId = val; }
});
window.deleteSession = deleteSession;
 
// ================================================================
// 启动应用
// ================================================================
 
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function () {
    try {
      setupChat();
    } catch (e) {
      handleInitError(e);
    }
  });
} else {
  try {
    setupChat();
  } catch (e) {
    handleInitError(e);
  }
}
 
function handleInitError(err) {
  console.error('[灵知] 初始化失败：', err);
  showInitError(err);
}
 
function showInitError(err) {
  var messages = document.getElementById('chatMessages');
  if (!messages) return;
  messages.innerHTML =
    '<div class="chat-empty-tip" style="color:#ef4444;padding:30px 20px;text-align:left;">' +
    '<div style="font-size:1.05rem;font-weight:600;margin-bottom:10px;">⚠️ 初始化失败</div>' +
    '<div style="font-size:0.88rem;color:#6b7280;line-height:1.6;word-break:break-all;">' +
    String((err && err.stack) || err || '未知错误') +
    '</div></div>';
 }
